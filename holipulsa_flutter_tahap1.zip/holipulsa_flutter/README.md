# HoliPulsa — Flutter starter (Tahap 1)

Fondasi UI aplikasi Android PPOB dengan tema biru-putih.

## Isi tahap pertama
- Beranda dan kartu saldo demo
- Menu layanan: pulsa, paket data, token PLN, tagihan PLN, PDAM, BPJS, e-wallet, voucher game, internet
- Halaman formulir layanan (belum memproses transaksi)
- Riwayat transaksi kosong
- Pilihan jenis akun pelanggan/agen (pratinjau lokal)
- Tampilan formulir masuk/daftar (belum terhubung ke server)

## Menjalankan sebagai proyek Flutter
1. Pasang Flutter SDK dan Android Studio pada komputer.
2. Buat proyek Android kosong: `flutter create holipulsa`
3. Salin folder `lib/` dari paket ini ke proyek tersebut (timpa `lib/` bawaan).
4. Ganti `pubspec.yaml` dengan file dari paket ini.
5. Dari folder proyek jalankan:
   ```bash
   flutter pub get
   flutter run
   ```
6. Untuk membuat APK debug:
   ```bash
   flutter build apk --debug
   ```
   APK biasanya berada di `build/app/outputs/flutter-apk/app-debug.apk`.

## Status dan batasan
Ini adalah prototipe antarmuka tahap pertama, bukan aplikasi transaksi produksi dan belum merupakan APK siap instal. Saldo Rp0, akun, peran, produk, dan transaksi masih data/tampilan demo. Belum ada autentikasi server, database, payment gateway, API PPOB, validasi transaksi, atau panel admin.

## Tahap berikutnya sebelum transaksi nyata
- Pilih vendor API PPOB setelah membandingkan cakupan produk, harga, deposit, SLA, sandbox, callback/webhook, dan ketentuan bisnis.
- Bangun backend aman untuk menyimpan akun, saldo, ledger, order, callback, dan audit log.
- Integrasikan pembayaran deposit dan rekonsiliasi.
- Buat dashboard admin dan kontrol agen.
- Uji sandbox, idempotensi, status pending/gagal/sukses, refund, dan keamanan sebelum produksi.

Jangan pernah menaruh API key/secret vendor di aplikasi Android. Simpan rahasia hanya di backend.
