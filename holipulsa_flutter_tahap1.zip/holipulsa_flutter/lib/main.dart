import 'package:flutter/material.dart';

void main() => runApp(const HoliPulsaApp());

const Color brandBlue = Color(0xFF1769D2);
const Color paleBlue = Color(0xFFEAF3FF);

class HoliPulsaApp extends StatelessWidget {
  const HoliPulsaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HoliPulsa',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: brandBlue),
        scaffoldBackgroundColor: const Color(0xFFF7F9FC),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Color(0xFF14243A),
          elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFFF4F7FB),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;
  String _role = 'Pelanggan';

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(role: _role, onServiceTap: _openService),
      const ServicesPage(),
      const HistoryPage(),
      AccountPage(role: _role, onRoleChanged: (value) => setState(() => _role = value)),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _index, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Beranda'),
          NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'Layanan'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Riwayat'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Akun'),
        ],
      ),
    );
  }

  void _openService(ServiceItem service) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => ServiceFormPage(service: service)));
  }
}

class ServiceItem {
  final String title;
  final IconData icon;
  final String description;
  const ServiceItem(this.title, this.icon, this.description);
}

const services = <ServiceItem>[
  ServiceItem('Pulsa', Icons.phone_android, 'Isi pulsa semua operator'),
  ServiceItem('Paket Data', Icons.wifi, 'Paket internet berbagai operator'),
  ServiceItem('Token PLN', Icons.bolt, 'Pembelian token listrik prabayar'),
  ServiceItem('Tagihan PLN', Icons.lightbulb_outline, 'Bayar listrik pascabayar'),
  ServiceItem('PDAM', Icons.water_drop_outlined, 'Pembayaran tagihan air'),
  ServiceItem('BPJS', Icons.health_and_safety_outlined, 'Pembayaran iuran BPJS'),
  ServiceItem('E-Wallet', Icons.account_balance_wallet_outlined, 'Isi saldo dompet digital'),
  ServiceItem('Voucher Game', Icons.sports_esports_outlined, 'Voucher dan top up game'),
  ServiceItem('Internet', Icons.router_outlined, 'Pembayaran internet rumah'),
];

class HomePage extends StatelessWidget {
  final String role;
  final ValueChanged<ServiceItem> onServiceTap;
  const HomePage({super.key, required this.role, required this.onServiceTap});

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
            child: Row(children: [
              Container(
                width: 46, height: 46,
                decoration: BoxDecoration(color: brandBlue, borderRadius: BorderRadius.circular(15)),
                child: const Center(child: Text('H', style: TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w900))),
              ),
              const SizedBox(width: 12),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('HoliPulsa', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: Color(0xFF14243A))),
                Text('Satu Aplikasi, Semua Transaksi', style: TextStyle(fontSize: 11, color: Colors.blueGrey)),
              ])),
              IconButton(onPressed: () => _showInfo(context, 'Notifikasi', 'Notifikasi transaksi akan tersedia setelah backend dihubungkan.'), icon: const Icon(Icons.notifications_none_rounded)),
            ]),
          ),
        ),
        SliverToBoxAdapter(
          child: Container(
            margin: const EdgeInsets.fromLTRB(20, 12, 20, 22),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF1769D2), Color(0xFF398BEA)], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(23),
              boxShadow: [BoxShadow(color: brandBlue.withValues(alpha: .18), blurRadius: 18, offset: const Offset(0, 8))],
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [const Expanded(child: Text('Saldo HoliPulsa', style: TextStyle(color: Colors.white70))), _roleChip(role)]),
              const SizedBox(height: 7),
              const Text('Rp0', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)),
              const SizedBox(height: 18),
              Row(children: [
                FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: brandBlue),
                  onPressed: () => _showInfo(context, 'Isi Saldo', 'Fitur deposit akan diaktifkan setelah metode pembayaran dan backend tersedia.'),
                  icon: const Icon(Icons.add, size: 18), label: const Text('Isi Saldo'),
                ),
                const SizedBox(width: 10),
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white70)),
                  onPressed: () => _showInfo(context, 'Mutasi Saldo', 'Riwayat saldo akan muncul setelah akun dan server aktif.'),
                  icon: const Icon(Icons.history, size: 18), label: const Text('Mutasi'),
                ),
              ]),
            ]),
          ),
        ),
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('Layanan Digital', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            TextButton(onPressed: () => onServiceTap(services.first), child: const Text('Coba layanan')),
          ]),
        )),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 18),
          sliver: SliverGrid(
            delegate: SliverChildBuilderDelegate((context, index) => _ServiceTile(item: services[index], onTap: () => onServiceTap(services[index])), childCount: services.length),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .95),
          ),
        ),
        SliverToBoxAdapter(child: Container(
          margin: const EdgeInsets.fromLTRB(20, 4, 20, 24), padding: const EdgeInsets.all(17),
          decoration: BoxDecoration(color: paleBlue, borderRadius: BorderRadius.circular(18)),
          child: Row(children: [
            const CircleAvatar(backgroundColor: Colors.white, child: Icon(Icons.storefront_outlined, color: brandBlue)),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Jadi Agen HoliPulsa', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF174B8B))),
              SizedBox(height: 3), Text('Dapatkan harga khusus untuk peluang usaha digital.', style: TextStyle(fontSize: 11, color: Color(0xFF42658C))),
            ])),
            const Icon(Icons.chevron_right, color: brandBlue),
          ]),
        )),
      ],
    );
  }
}

Widget _roleChip(String role) => Container(
  padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
  decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18), borderRadius: BorderRadius.circular(30)),
  child: Text(role, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
);

class _ServiceTile extends StatelessWidget {
  final ServiceItem item;
  final VoidCallback onTap;
  const _ServiceTile({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
    color: Colors.white, borderRadius: BorderRadius.circular(17),
    child: InkWell(borderRadius: BorderRadius.circular(17), onTap: onTap, child: Padding(
      padding: const EdgeInsets.all(9),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 47, height: 47, decoration: BoxDecoration(color: paleBlue, borderRadius: BorderRadius.circular(15)), child: Icon(item.icon, color: brandBlue, size: 25)),
        const SizedBox(height: 9),
        Text(item.title, textAlign: TextAlign.center, maxLines: 2, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
      ]),
    )),
  );
}

class ServicesPage extends StatelessWidget {
  const ServicesPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Semua Layanan', style: TextStyle(fontWeight: FontWeight.w800))),
    body: ListView.separated(
      padding: const EdgeInsets.all(18), itemCount: services.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, i) => ListTile(
        tileColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        leading: CircleAvatar(backgroundColor: paleBlue, child: Icon(services[i].icon, color: brandBlue)),
        title: Text(services[i].title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(services[i].description), trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ServiceFormPage(service: services[i]))),
      ),
    ),
  );
}

class ServiceFormPage extends StatefulWidget {
  final ServiceItem service;
  const ServiceFormPage({super.key, required this.service});
  @override
  State<ServiceFormPage> createState() => _ServiceFormPageState();
}

class _ServiceFormPageState extends State<ServiceFormPage> {
  final _number = TextEditingController();
  @override
  void dispose() { _number.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.service.title, style: const TextStyle(fontWeight: FontWeight.w800))),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: paleBlue, borderRadius: BorderRadius.circular(18)), child: Row(children: [Icon(widget.service.icon, color: brandBlue, size: 34), const SizedBox(width: 12), Expanded(child: Text(widget.service.description, style: const TextStyle(fontWeight: FontWeight.w600)))])),
      const SizedBox(height: 24),
      Text(widget.service.title == 'Token PLN' || widget.service.title == 'Tagihan PLN' ? 'Nomor meter / ID pelanggan' : 'Nomor tujuan', style: const TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 9),
      TextField(controller: _number, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: 'Masukkan nomor tujuan', prefixIcon: Icon(Icons.numbers))),
      const SizedBox(height: 18),
      const Text('Pilihan produk', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)), child: const Row(children: [Icon(Icons.info_outline, color: brandBlue), SizedBox(width: 10), Expanded(child: Text('Daftar nominal dan harga akan dimuat dari penyedia API PPOB setelah integrasi.', style: TextStyle(fontSize: 12, color: Colors.blueGrey)))])),
      const SizedBox(height: 25),
      FilledButton(onPressed: () {
        if (_number.text.trim().isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Masukkan nomor tujuan terlebih dahulu.'))); return; }
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mode demo: transaksi belum diproses. API PPOB belum terhubung.')));
      }, child: const Padding(padding: EdgeInsets.all(14), child: Text('Lanjutkan'))),
      const SizedBox(height: 10),
      const Text('Transaksi pada versi ini hanya simulasi. Jangan melakukan pembayaran berdasarkan tampilan demo.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.blueGrey)),
    ]),
  );
}

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Riwayat Transaksi', style: TextStyle(fontWeight: FontWeight.w800))),
    body: Center(child: Padding(padding: const EdgeInsets.all(30), child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 82, height: 82, decoration: const BoxDecoration(color: paleBlue, shape: BoxShape.circle), child: const Icon(Icons.receipt_long_outlined, color: brandBlue, size: 38)),
      const SizedBox(height: 16), const Text('Belum ada transaksi', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      const SizedBox(height: 6), const Text('Riwayat pembelian dan pembayaran akan tampil di sini.', textAlign: TextAlign.center, style: TextStyle(color: Colors.blueGrey)),
    ]))),
  );
}

class AccountPage extends StatelessWidget {
  final String role;
  final ValueChanged<String> onRoleChanged;
  const AccountPage({super.key, required this.role, required this.onRoleChanged});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Akun Saya', style: TextStyle(fontWeight: FontWeight.w800))),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)), child: Row(children: [const CircleAvatar(radius: 27, backgroundColor: paleBlue, child: Icon(Icons.person, color: brandBlue, size: 30)), const SizedBox(width: 13), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Pengguna HoliPulsa', style: TextStyle(fontWeight: FontWeight.w800)), Text('Mode demo • $role', style: const TextStyle(color: Colors.blueGrey, fontSize: 12))])), const Icon(Icons.verified_user_outlined, color: brandBlue)])),
      const SizedBox(height: 22), const Text('Jenis akun', style: TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 9),
      _RoleOption(title: 'Pelanggan', subtitle: 'Belanja produk digital untuk kebutuhan pribadi', selected: role == 'Pelanggan', onTap: () => onRoleChanged('Pelanggan')),
      const SizedBox(height: 10), _RoleOption(title: 'Agen / Reseller', subtitle: 'Akses konsep harga khusus untuk mitra penjualan', selected: role == 'Agen', onTap: () => onRoleChanged('Agen')),
      const SizedBox(height: 22),
      OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AuthPage())), icon: const Icon(Icons.login), label: const Text('Masuk / Daftar akun')),
      const SizedBox(height: 12),
      const Text('Pilihan jenis akun di versi ini hanya untuk pratinjau. Pendaftaran dan hak akses sebenarnya memerlukan backend.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.blueGrey)),
    ]),
  );
}

class _RoleOption extends StatelessWidget {
  final String title, subtitle;
  final bool selected;
  final VoidCallback onTap;
  const _RoleOption({required this.title, required this.subtitle, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) => Material(color: Colors.white, borderRadius: BorderRadius.circular(15), child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(15), child: Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), border: Border.all(color: selected ? brandBlue : Colors.transparent, width: 1.5)), child: Row(children: [Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off, color: brandBlue), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.blueGrey))]))]))));
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool register = true;
  String role = 'Pelanggan';
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(register ? 'Daftar HoliPulsa' : 'Masuk HoliPulsa')),
    body: ListView(padding: const EdgeInsets.all(22), children: [
      const SizedBox(height: 12), const Center(child: Text('HoliPulsa', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, color: brandBlue))),
      const SizedBox(height: 5), Center(child: Text(register ? 'Buat akun baru Anda' : 'Selamat datang kembali', style: const TextStyle(color: Colors.blueGrey))),
      const SizedBox(height: 28),
      if (register) ...[
        const Text('Nama lengkap'), const SizedBox(height: 7), const TextField(decoration: InputDecoration(hintText: 'Nama Anda', prefixIcon: Icon(Icons.person_outline))), const SizedBox(height: 15),
      ],
      const Text('Nomor WhatsApp'), const SizedBox(height: 7), const TextField(keyboardType: TextInputType.phone, decoration: InputDecoration(hintText: '08xxxxxxxxxx', prefixIcon: Icon(Icons.phone_outlined))), const SizedBox(height: 15),
      const Text('Kata sandi'), const SizedBox(height: 7), const TextField(obscureText: true, decoration: InputDecoration(hintText: 'Masukkan kata sandi', prefixIcon: Icon(Icons.lock_outline))),
      if (register) ...[
        const SizedBox(height: 18), const Text('Daftar sebagai', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 8),
        SegmentedButton<String>(segments: const [ButtonSegment(value: 'Pelanggan', label: Text('Pelanggan'), icon: Icon(Icons.person_outline)), ButtonSegment(value: 'Agen', label: Text('Agen'), icon: Icon(Icons.storefront_outlined))], selected: {role}, onSelectionChanged: (v) => setState(() => role = v.first)),
      ],
      const SizedBox(height: 24),
      FilledButton(onPressed: () => _showInfo(context, 'Mode demo', 'Formulir ini belum mengirim data. Sistem login aman akan dibuat saat backend disiapkan.'), child: Padding(padding: const EdgeInsets.all(13), child: Text(register ? 'Buat Akun' : 'Masuk'))),
      TextButton(onPressed: () => setState(() => register = !register), child: Text(register ? 'Sudah punya akun? Masuk' : 'Belum punya akun? Daftar')),
    ]),
  );
}

void _showInfo(BuildContext context, String title, String message) => showDialog<void>(context: context, builder: (context) => AlertDialog(title: Text(title), content: Text(message), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Mengerti'))]));
